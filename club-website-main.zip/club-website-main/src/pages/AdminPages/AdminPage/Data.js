import Admin from '../../../images/admin.png'

export const StartingSectionParameters = {
  headingText: 'Admin',
  image: Admin,
  descriptionText: "This secret page is for executives of the club to edit content on the site"
}
