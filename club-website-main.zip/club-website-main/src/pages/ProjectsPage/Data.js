import projectsImg from '../../images/projects.png'

export const StartingSectionParameters = {
  headingText: 'Projects',
  image: projectsImg,
  descriptionText: "This page contains a list of really cool projects completed by the Bethune Computer Science Club, as well the personal projects of executives and general members!"
}

