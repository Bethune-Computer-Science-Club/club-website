import WebsitesPagePic from './../../images/WebsitesPagePic.jpg'

export const BannerInfo = {
    headingText: "Websites",
    image: WebsitesPagePic,
    descriptionText: "Cool sites on the web!",
}