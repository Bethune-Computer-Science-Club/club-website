import RoboticsPic from './../../images/Robotics.png'

export const BannerInfo = {
  headingText: "Robotics",
  image: RoboticsPic,
  descriptionText: "Beep Boop, Beep Boop.",
}