import AIPagePic from './../../images/AIPagePic.jpg'

export const BannerInfo = {
    headingText: "AI",
    image: AIPagePic,
    descriptionText: "Smart programs for smart tasks!",
}
