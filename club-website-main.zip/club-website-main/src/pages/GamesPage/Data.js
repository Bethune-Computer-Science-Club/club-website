import GamingPagePic from './../../images/GamingPagePic.png'

export const BannerInfo = {

    headingText: "Games",
    image: GamingPagePic,
    descriptionText: "Get your game on with these awesome creations!",

}
