//import BCSCLogo from '../../images/BCSCLogo.png'
import ApplicationsLogo from './../../images/ApplicationsLogo.png'

export const BannerInfo = {

    headingText: "Applications",
    image: ApplicationsLogo,
    descriptionText: "Useful programs that perform a variety of functions!",

}