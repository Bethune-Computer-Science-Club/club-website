import OtherPagePic from './../../images/OtherPagePic.png'

export const BannerInfo = {

    headingText: "Miscellaneous",
    image: OtherPagePic,
    descriptionText: "Other cool projects!",

}
