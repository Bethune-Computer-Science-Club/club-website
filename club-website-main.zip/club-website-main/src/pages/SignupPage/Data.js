import Admin from '../../images/admin.png'

export const StartingSectionParameters = {
  headingText: 'Signup',
  image: Admin,
  descriptionText: "This site is for executives of the club to edit content on the main site"
}

